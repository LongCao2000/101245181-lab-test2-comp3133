module.exports = {
    client: {
        service: {
            name: 'angular-spacex-graphql-codegen',
            url: 'https://api.spacexdata.com/v3/launches'
        }
    }
};