import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { PastMissionsListGQL, PastMissionsListQuery } from '../services/spacexGraphql.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-mission-list',
  templateUrl: './mission-list.component.html',
  styleUrls: ['./mission-list.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MissionListComponent implements OnInit {

  constructor(private pastMissionService: PastMissionsListGQL) { }

    pastMission$ = this.pastMissionService
      .fetch({ limit: 30})
      .pipe(
        map(
          res => res.data.launchesPast
        )
      );

  ngOnInit(){}

}
