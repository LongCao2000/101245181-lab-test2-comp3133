import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { map, switchMap } from 'rxjs/operators';
import { MissionDetailsGQL } from '../services/spacexGraphql.service';

@Component({
  selector: 'app-mission-details',
  templateUrl: './mission-details.component.html',
  styleUrls: ['./mission-details.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MissionDetailsComponent implements OnInit {

  constructor(
    private readonly route: ActivatedRoute,
    private readonly missionDetailsService: MissionDetailsGQL
) { }
    
    missionDetails$ = this.route.paramMap.pipe(
      switchMap(params => {
        const id = params.get('id');
        return this.missionDetailsService.fetch({ id });
      }),
      map(res => res.data.launch)
    );

  ngOnInit() {}

}
